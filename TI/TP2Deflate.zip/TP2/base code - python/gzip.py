# Author: Marco Simoes
# Adapted from Java's implementation of Rui Pedro Paiva
# Teoria da Informacao, LEI, 2022

import sys
from huffmantree import HuffmanTree


class GZIPHeader:
	''' class for reading and storing GZIP header fields '''

	ID1 = ID2 = CM = FLG = XFL = OS = 0
	MTIME = []
	lenMTIME = 4
	mTime = 0

	# bits 0, 1, 2, 3 and 4, respectively (remaining 3 bits: reserved)
	FLG_FTEXT = FLG_FHCRC = FLG_FEXTRA = FLG_FNAME = FLG_FCOMMENT = 0   
	
	# FLG_FTEXT --> ignored (usually 0)
	# if FLG_FEXTRA == 1
	XLEN, extraField = [], []
	lenXLEN = 2
	
	# if FLG_FNAME == 1
	fName = ''  # ends when a byte with value 0 is read
	
	# if FLG_FCOMMENT == 1
	fComment = ''   # ends when a byte with value 0 is read
		
	# if FLG_HCRC == 1
	HCRC = []
		
		
	
	def read(self, f):
		''' reads and processes the Huffman header from file. Returns 0 if no error, -1 otherwise '''

		# ID 1 and 2: fixed values
		self.ID1 = f.read(1)[0]  
		if self.ID1 != 0x1f: return -1 # error in the header
			
		self.ID2 = f.read(1)[0]
		if self.ID2 != 0x8b: return -1 # error in the header
		
		# CM - Compression Method: must be the value 8 for deflate
		self.CM = f.read(1)[0]
		if self.CM != 0x08: return -1 # error in the header
					
		# Flags
		self.FLG = f.read(1)[0]
		
		# MTIME
		self.MTIME = [0]*self.lenMTIME
		self.mTime = 0
		for i in range(self.lenMTIME):
			self.MTIME[i] = f.read(1)[0]
			self.mTime += self.MTIME[i] << (8 * i) 				
						
		# XFL (not processed...)
		self.XFL = f.read(1)[0]
		
		# OS (not processed...)
		self.OS = f.read(1)[0]
		
		# --- Check Flags
		self.FLG_FTEXT = self.FLG & 0x01
		self.FLG_FHCRC = (self.FLG & 0x02) >> 1
		self.FLG_FEXTRA = (self.FLG & 0x04) >> 2
		self.FLG_FNAME = (self.FLG & 0x08) >> 3
		self.FLG_FCOMMENT = (self.FLG & 0x10) >> 4
					
		# FLG_EXTRA
		if self.FLG_FEXTRA == 1:
			# read 2 bytes XLEN + XLEN bytes de extra field
			# 1st byte: LSB, 2nd: MSB
			self.XLEN = [0]*self.lenXLEN
			self.XLEN[0] = f.read(1)[0]
			self.XLEN[1] = f.read(1)[0]
			self.xlen = self.XLEN[1] << 8 + self.XLEN[0]
			
			# read extraField and ignore its values
			self.extraField = f.read(self.xlen)
		
		def read_str_until_0(f):
			s = ''
			while True:
				c = f.read(1)[0]
				if c == 0: 
					return s
				s += chr(c)
		
		# FLG_FNAME
		if self.FLG_FNAME == 1:
			self.fName = read_str_until_0(f)
		
		# FLG_FCOMMENT
		if self.FLG_FCOMMENT == 1:
			self.fComment = read_str_until_0(f)
		
		# FLG_FHCRC (not processed...)
		if self.FLG_FHCRC == 1:
			self.HCRC = f.read(2)
			
		return 0
			



class GZIP:
	''' class for GZIP decompressing file (if compressed with deflate) '''

	gzh = None
	gzFile = ''
	fileSize = origFileSize = -1
	numBlocks = 0
	f = None
	

	bits_buffer = 0
	available_bits = 0		

	
	def __init__(self, filename):
		self.gzFile = filename
		self.f = open(filename, 'rb')
		self.f.seek(0,2)
		self.fileSize = self.f.tell()
		self.f.seek(0)

		
	

	def decompress(self):
		''' main function for decompressing the gzip file with deflate algorithm '''
		
		numBlocks = 0

		# get original file size: size of file before compression
		origFileSize = self.getOrigFileSize()
		print(origFileSize)
		
		# read GZIP header
		error = self.getHeader()
		if error != 0:
			print('Formato invalido!')
			return
		
		# show filename read from GZIP header
		print(self.gzh.fName)
		
		
		# MAIN LOOP - decode block by block
		BFINAL = 0	
		while not BFINAL == 1:	
			
			BFINAL = self.readBits(1)
							
			BTYPE = self.readBits(2)					
			if BTYPE != 2:
				print('Error: Block %d not coded with Huffman Dynamic coding' % (numBlocks+1))
				return
			
									
			#--- STUDENTS --- ADD CODE HERE
			# 
			#
			# Ponto 1
			print("\n----------------> Ponto 1 <----------------")
			hlit = self.readBits(5)
			hdist = self.readBits(5)
			hclen = self.readBits(4)
			print(f"HLIT = {hlit} bits")
			print(f"HDIST = {hdist} bits")
			print(f"HCLEN = {hclen} bits")
   
			# Ponto 2
			print("\n----------------> Ponto 2 <----------------")
			arrayLens = self.getArrayLen(hclen)
			print("Array com os comprimentos dos códigos do 'alfabeto de comprimentos de códigos', com base em HCLEN:")
			print(arrayLens)
   
			# Ponto 3
			print("\n----------------> Ponto 3 <----------------")
			print("Adição dos códigos de Huffman à árvore:\n")
			orderList = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]
			hfTree = self.getHuffTree(arrayLens, orderList)
			
			print(hfTree)
   
			# Ponto 4
			print("\n----------------> Ponto 4 <----------------")
			print("Array com os HLIT + 257 comprimentos dos códigos referentes ao alfabeto de literais/comprimentos codificados segundo o código de Huffman de comprimentos de códigos:")
			arrayLitLen = self.getLitDistLen(hfTree, hlit, "HLIT")
			print(arrayLitLen)
      
      		# Ponto 5
			print("\n----------------> Ponto 5 <----------------")
			print("Array com os HDIST + 1 comprimentos dos códigos referentes ao alfabeto de literais/comprimentos codificados segundo o código de Huffman de comprimentos de códigos:")
			arrayDistLen = self.getLitDistLen(hfTree, hdist, "HDIST")
			print(arrayDistLen)

			# Ponto 6
			print("\n----------------> Ponto 6 <----------------")
			print("Adição dos códigos de Huffman à árvore: (alfabeto literais comprimentos)\n")
			hfTreeLit = self.getHuffTree(arrayLitLen, None)
			print(hfTreeLit)
			print("\n\nAdição dos códigos de Huffman à árvore: (alfabeto literais distâncias)\n")
			hfTreeDist = self.getHuffTree(arrayDistLen, None)
			print(hfTreeDist)
   
			# Ponto 7
			print("\n----------------> Ponto 7 <----------------")
			if(numBlocks == 0): lastBuff = None
			decodedCodes = self.getDecoded(hfTreeLit, hfTreeDist, lastBuff)
			lastBuff = decodedCodes  # Guarda os simbolos descodificados do último bloco lido para caso sejam necessários no próximo bloco

			# Ponto 8
			print("\n----------------> Ponto 8 <----------------")
			decodedCodesByteArray = bytearray(decodedCodes)
			if(numBlocks == 0): mode = "wb"
			else: mode = "ab"
			with open(self.gzh.fName, mode) as binaryFile:
				binaryFile.write(decodedCodesByteArray)
																																								
			# update number of blocks read
			numBlocks += 1
		
		# close file			
		
		self.f.close()	
		print("End: %d block(s) analyzed." % numBlocks)
  
  
	def getArrayLen(self, hclen):
		'''
		Calcula e retorna o array com os valores de cada grupo de 3 bits seguintes de acordo com o valor de HCLEN.
  		'''
		arrayLen = []
		# Repetição de acordo com a quantidade de conjuntos de 3 bits seguinte retirada do valor de hclen ((HCLEN+4) * 3 bits) 
		for i in range(hclen+4):
			# Adição do valor contido no conjunto de 3 bits no array de comprimentos
			arrayLen.append(self.readBits(3))
		return arrayLen


	def getHuffTree(self, arrayLens, orderList):
		'''
		Cria e devolve a árvore de Huffman, de acordo com o array de comprimentos passado por 'arrayLens' e caso haja ordem na sua codificação (como no caso do HCLEN), deve ser passada a sua ordem,
		caso não haja ordem este parametro deve ser passado como None (NULL)
    	'''
		# Criação da lista com as contagem de cada comprimento de código presente na arrayLen
		count = [0]  # Não existem simbolos com comprimento 0
		for i in range(1, max(arrayLens)+1):
			count.append(arrayLens.count(i))
		# Criação da lista com os primeiros códigos de cada comprimento
		code = 0
		codes = []
		for i in range(1, len(count)):
			code += count[i-1]
			code = code << 1
			codes.append(code)
		# Adição na árvore de Huffman dos simbolos de acordo com os seus códigos
		hfTree = HuffmanTree()
		# Definição da quantidade de simbolos maximos que serão lidos
		if(orderList != None): simbCount = len(orderList)  # Caso haja uma ordem pré definida, o máximo de simbolos a codificar é o comprimento do array com a ordem pela qual os simbolos devem aparecer
		else: simbCount = len(arrayLens)				   # Caso não haja ordem, o número máximo/exato de simbolos a codificar é o comprimento do próprio array de comprimentos
		for simb in range(simbCount):
			# Caso haja ordem, o index não será sequencial mas sim a posição determinada de acordo com a ordem
			if(orderList != None):
				index = orderList.index(simb)
			# Caso não haja ordem o index é sequencial assim como 'simb' (percorre o array de comprimentos)
			else:
				index = simb
			if(index < len(arrayLens)):
				if(arrayLens[index] == 0): continue  						 # Caso o simbolo tenha comprimento 0 (não esteja representado)
				codeStr = bin(codes[arrayLens[index]-1])[2:]  				 # String com o código em binário (pode não conter o comprimento necessário)
				hfTree.addNode(codeStr.zfill(arrayLens[index]), simb, True)  # Adição na árvore do código correspondente, com o comprimento correto ajustado pela função zfill() que acrescenta zeros à esquerda até atingir um comprimento desejado
				codes[arrayLens[index]-1] += 1								 # Adição de mais uma unidade para o próximo código com comprimento X se existir
		
		return hfTree


	def getLitDistLen(self, hfTree, hlit_or_hdist, mode):
		'''
		Calcula e retorna o array dos comprimentos de códigos referentes ao alfabeto de literais/comprimentos
		codificados segundo o código de Huffman de comprimentos de códigos.

		mode --> 'HLIT' ou 'HDIST' dependendo do pretendido
  		'''
		arrayLitDistLen = []
		# Modifica a quantidade de simbolos a descodificar de acordo com os parametros passados
		if(mode == "HLIT"): maxLen = hlit_or_hdist + 257
		elif(mode == "HDIST"): maxLen = hlit_or_hdist + 1
		else:
			print(f"Mode '{mode}' don't exist, please use 'HLIT' or 'HDIST' as mode.")
			return
		while(len(arrayLitDistLen) < maxLen):
			done = False  # Variável de controlo
			while not done:
				pos = hfTree.nextNode(str(self.readBits(1)))  # Le o próximo bit e avança na árvore de huffman
				# Caso a árvore tenha chegado a uma folha (ou tenha saido sem encontrar nenhuma folha)
				if(pos != -2):
					# Caso onde ocorreu algum erro (saiu da árvore sem chegar a uma folha)
					assert(pos != -1), "Error... huffman code not found."
					# Caso a folha seja correspondente ao simbolo 16
					if(pos == 16):
						assert(len(arrayLitDistLen) != 0), "Error... the first number of lenghts readed was 16, so there is no lengh before to use."
						extra = int(self.readBits(2)) 					     # Le dois bits adicionais
						lastLen = arrayLitDistLen[len(arrayLitDistLen) - 1]  # Verifica qual foi o último simbolo adicionado no array para pode-lo repetir 'extra' + 3 vezes
						for i in range(extra + 3):
							arrayLitDistLen.append(lastLen)
							if(len(arrayLitDistLen) >= maxLen): break
					# Caso a folha seja correspondente ao simbolo 17
					elif(pos == 17):
						extra = int(self.readBits(3))  # Le três bits adicionais
						for i in range(extra + 3):
							arrayLitDistLen.append(0)  # Adição de 'extra' + 3 zeros
							if(len(arrayLitDistLen) >= maxLen): break
					# Caso a folha seja correspondente ao simbolo 18
					elif(pos == 18):
						extra = int(self.readBits(7))  # Le sete bits adicionais
						for i in range(extra + 11):
							arrayLitDistLen.append(0)  # Adição de 'extra' + 11 zeros
							if(len(arrayLitDistLen) >= maxLen): break
					# Caso a folha seja correspondente a qualquer simbolo entre 0 e 15 inclusive
					else:
						arrayLitDistLen.append(pos)
					done = True    # Atualização da variável de controlo para possibilitar sair do ciclo
			hfTree.resetCurNode()  # Após chegada a uma folha e processado o seu resultado, reset da posição na árvore (retorno à raiz)
		return arrayLitDistLen


	def getDecoded(self, hfTreeLit, hfTreeDist, lastBuff):
		'''
		Descodifica e retorna a lista de simbolos descomprimidos de acordo com as árvores de huffman referentes aos literais/comprimentos e distâncias a recuar
  		'''
		decodedCodes = []
		endBlock = False  # Variável de controlo que verifica quando o bloco foi inteiramente lido
		while not endBlock:
			done = False  # Variável de controlo que verifica quando um novo simbolo, ou conjunto de simbolos, foi descomprimido e acrescentado à lista de simbolos descomprimidos
			while not done:
				symbol = hfTreeLit.nextNode(str(self.readBits(1)))  # Le o próximo bit e avança na árvore de huffman dos literais/comprimentos
				# Caso a árvore dos literais/comprimentos tenha chegado a uma folha (ou tenha saido sem encontrar nenhuma folha)
				if(symbol != -2):
					# Caso onde ocorreu algum erro (saiu da árvore sem chegar a uma folha)
					assert(symbol != -1), "Error... huffman code not found."
					# Caso a folha encontrada tenha sido um literal
					if(symbol < 256): decodedCodes.append(symbol)
					# Caso a folha encontrada tenha sido o simbolo 256 que equivale ao fim do bloco
					elif(symbol == 256): endBlock = True
					# Caso a folha não seja um literal, ou seja, um conjunto de simbolos já existentes e descodificados
					else:
						# Descodificação do comprimento
						if(symbol < 265): length = symbol - 254
						elif(symbol < 269): length = (11 + (symbol - 265)*2 + self.readBits(1))
						elif(symbol < 273): length = (19 + (symbol - 269)*4 + self.readBits(2))
						elif(symbol < 277): length = (35 + (symbol - 273)*8 + self.readBits(3))
						elif(symbol < 281): length = (67 + (symbol - 277)*16 + self.readBits(4))
						elif(symbol < 285): length = (131 + (symbol - 281)*32 + self.readBits(5))
						else: length = 258
						distDone = False  # Variável de controlo que verifica quando a distância a recuar foi descodificada
						# Descodificação da distância a recuar
						while not distDone:
							dist = hfTreeDist.nextNode(str(self.readBits(1)))  # Le o próximo bit e avança na árvore de huffman das distâncias
							# Caso a árvore das distâncias tenha chegado a uma folha (ou tenha saido sem encontrar nenhuma folha)
							if(dist != -2):
								assert(dist != -1), "Error... huffman code not found."  # Caso onde ocorreu algum erro (saiu da árvore sem chegar a uma folha)
								if(dist < 4): dist += 1
								elif(dist < 6): dist = (5 + (dist - 4)*2 + self.readBits(1))
								elif(dist < 8): dist = (9 + (dist - 6)*4 + self.readBits(2))
								elif(dist < 10): dist = (17 + (dist - 8)*8 + self.readBits(3))
								elif(dist < 12): dist = (33 + (dist - 10)*16 + self.readBits(4))
								elif(dist < 14): dist = (65 + (dist - 12)*32 + self.readBits(5))
								elif(dist < 16): dist = (129 + (dist - 14)*64 + self.readBits(6))
								elif(dist < 18): dist = (257 + (dist - 16)*128 + self.readBits(7))
								elif(dist < 20): dist = (513 + (dist - 18)*256 + self.readBits(8))
								elif(dist < 22): dist = (1025 + (dist - 20)*512 + self.readBits(9))
								elif(dist < 24): dist = (2049 + (dist - 22)*1024 + self.readBits(10))
								elif(dist < 26): dist = (4097 + (dist - 24)*2048 + self.readBits(11))
								elif(dist < 28): dist = (8193 + (dist - 26)*4096 + self.readBits(12))
								else: dist = (16385 + (dist - 28)*8192 + self.readBits(13))
								distDone = True    # Atualização da variável de controlo para possibilitar sair do ciclo das distâncias
						hfTreeDist.resetCurNode()  # Após chegada a uma folha e processado o seu resultado, reset da posição na árvore das distâncias (retorno à raiz)
						size = len(decodedCodes)   # Quantidade atual de simbolos descomprimidos
						if(lastBuff != None): size2 = len(lastBuff)  # Quantidade de simbolos descomprimidos no bloco anterior caso exista
						for i in range(length):
							# Adição à lista a sequência de 'length' simbolos de acordo com a distância a recuar desde o final da lista
							if((size - dist + i) < 0): decodedCodes.append(lastBuff[size2 - (dist - size) + i])  # Caso a distância necessite recuar aos códigos do bloco anterior
							else: decodedCodes.append(decodedCodes[size - dist + i]) 						     # Caso os simbolos a copiar estejam no mesmo bloco
					done = True       # Atualização da variável de controlo para possibilitar sair do ciclo da adição de simbolos
			hfTreeLit.resetCurNode()  # Após chegada a uma folha e processado o seu resultado, reset da posição na árvore dos literais/comprimentos (retorno à raiz)
		return decodedCodes

	def getOrigFileSize(self):
		''' reads file size of original file (before compression) - ISIZE '''
		
		# saves current position of file pointer
		fp = self.f.tell()
		
		# jumps to end-4 position
		self.f.seek(self.fileSize-4)
		
		# reads the last 4 bytes (LITTLE ENDIAN)
		sz = 0
		for i in range(4): 
			sz += self.f.read(1)[0] << (8*i)
		
		# restores file pointer to its original position
		self.f.seek(fp)
		
		return sz		
	

	
	def getHeader(self):  
		''' reads GZIP header'''

		self.gzh = GZIPHeader()
		header_error = self.gzh.read(self.f)
		return header_error
		

	def readBits(self, n, keep=False):
		''' reads n bits from bits_buffer. if keep = True, leaves bits in the buffer for future accesses '''

		while n > self.available_bits:
			self.bits_buffer = self.f.read(1)[0] << self.available_bits | self.bits_buffer
			self.available_bits += 8
		
		mask = (2**n)-1
		value = self.bits_buffer & mask

		if not keep:
			self.bits_buffer >>= n
			self.available_bits -= n

		return value

	


if __name__ == '__main__':

	# gets filename from command line if provided
	fileName = "FAQ.txt.gz"
	if len(sys.argv) > 1:
		fileName = sys.argv[1]			

	# decompress file
	gz = GZIP(fileName)
	gz.decompress()
	